
package book.linkedlist;


import java.util.LinkedList;
import java.util.Scanner;
public class Book {
private final String title;
private final String author;
private final int year;
private static String genre;
public Book(String title, String author, int year) {
this.title = title;
this.author = author;
this.year = year;
}
public void display() {
System.out.println("Title: " + title);
System.out.println("Author: " + author);

System.out.println("Year: " + year);
System.out.println("Genre: " + genre);
System.out.println();
}
public static void getTotalBooks(LinkedList<Book> books) {
System.out.println("Total number of books: " + books.size());
}
public static void main(String[] args) {
   Scanner scanner = new Scanner(System.in);
        LinkedList<Book> books = new LinkedList<>();
        for (int i = 0; i < 3; i++) {
            System.out.println("Enter details for Book " + (i + 1) + ":");
            System.out.print("Title: ");
            String title = scanner.nextLine();
            System.out.print("Author: ");
            String author = scanner.nextLine();
            System.out.print("Year: ");
            int year = scanner.nextInt();
            scanner.nextLine();
            Book book = new Book(title, author, year);
            books.add(book);
        }
        
        System.out.println("\nAll Books:");
        for (Book book : books) {
            book.display();
        }
        Book.getTotalBooks(books);
    }
}
