package encapsulation.personset;

public class Person {
private String name;
private int age;
private String gender;
private String address;
public Person() {
this.name = "Unknown";
this.age = 0;
this.gender = "Unknown";
this.address = "Unknown";
}
public Person(String name, int age) {
this.name = name;
this.age = age;
this.gender = "Unknown";
this.address = "Unknown";
}
public Person(String name, int age, String gender, String address) {
this.name = name;
this.age = age;
this.gender = gender;
this.address = address;
}

public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
public int getAge() {
return age;
}
public void setAge(int age) {
this.age = age;
}
public String getGender() {
return gender;
}
public void setGender(String gender) {
this.gender = gender;
}
public String getAddress() {
return address;
}
public void setAddress(String address) {
this.address = address;
}
public void updatePerson(String name, int age) {
this.name = name;

this.age = age;
}
public void updatePerson(String gender, String address) {
this.gender = gender;
this.address = address;
}
public void displayPersonInfo() {
System.out.println("Name: " + this.name);
System.out.println("Age: " + this.age);
System.out.println("Gender: " + this.gender);
System.out.println("Address: " + this.address);
}
public static void main(String[] args) {
Person person1 = new Person();
person1.displayPersonInfo();
System.out.println();
Person person2 = new Person("ISRAT", 24);
person2.displayPersonInfo();
System.out.println();
Person person3 = new Person("RAHI", 30, "male", "Dhanmondi, Dhaka");
person3.displayPersonInfo();
System.out.println();
person2.updatePerson("ISMITA", 26);
person2.displayPersonInfo();
System.out.println();
person3.updatePerson("Female", "Paltan Avenue, Dhaka");

person3.displayPersonInfo();
}
}