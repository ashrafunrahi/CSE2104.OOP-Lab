

package matrix.matrix;
import java.util.Scanner;
public class Matrix {
public static void main(String[] args) {
    try (Scanner scanner = new Scanner(System.in)) {
        int[][] matrix1 = new int[2][2];
        int[][] matrix2 = new int[2][2];
        int[][] resultMatrix = new int[2][2];
        System.out.println("Enter the elements of the first matrix:");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                matrix1[i][j] = scanner.nextInt();
                
            }
        }
        System.out.println("Enter the elements of the second matrix:");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                matrix2[i][j] = scanner.nextInt();
            } }
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                resultMatrix[i][j] = 0;
                for (int k = 0; k < 2; k++) {
                    resultMatrix[i][j] += matrix1[i][k] * matrix2[i][k];
                }
            }
        }
        System.out.println("Resultant matrix after multiplication:");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(resultMatrix[i][j] + " ");
            } System.out.println();
        }   }

}
}