package book.arraylist;

import java.util.ArrayList;


public class Book {
private final String title;
private final String author;
private final int year;
private final String genre;
public Book(String title, String author, int year, String genre) {
this.title = title;
this.author = author;
this.year = year;
this.genre = genre;
}
public String getTitle() {
return title; }
public String getAuthor() {

return author; }
public int getYear() {
return year; }
public String getGenre() {
return genre; }
public void display() {
System.out.println("Title: " + title);
System.out.println("Author: " + author);
System.out.println("Year: " + year);
System.out.println("Genre: " + genre);
System.out.println();
}
public static void main(String[] args) {
ArrayList<Book> books = new ArrayList<>();
Book book1 = new Book("Book1 Title", "Author1", 2000, "Fiction");

Book book2 = new Book("Book2 Title", "Author2", 2010, "Nonfic");

Book book3 = new Book("Book3 Title", "Author3", 2020,
"Science");
books.add(book1);
books.add(book2);
books.add(book3);
System.out.println("All Books:");

for (Book book : books) {
book.display();
}
books.remove(book2);
System.out.println("Books after removing Book2:");
for (Book book : books) {
book.display();
}
}
}