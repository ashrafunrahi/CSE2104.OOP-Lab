package book.book;

import java.util.Scanner;
class Book {
private final String title;
private final String author;
private final int year;
private static String genre;
private static int bookCount = 0;
public Book(String title, String author, int year, String genre) {
this.title = title;
this.author = author;
this.year = year;
Book.genre = genre;
bookCount++;
}
public void displayDetails() {
System.out.println("Title: " + title);
System.out.println("Author: " + author);
System.out.println("Year: " + year);

System.out.println("Genre: " + genre);
System.out.println();
}
public static void displayTotalBooks() {
System.out.println("Total number of books: " + bookCount);
}
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
System.out.println("details please : title,author,year,genre");
System.out.println("Book 1:");
String title1 = scanner.nextLine();
String author1 = scanner.nextLine();
int year1 = scanner.nextInt();
scanner.nextLine();
String genre1 = scanner.nextLine();
Book book1 = new Book(title1, author1, year1, genre1);

System.out.println("Book 2:");
String title2 = scanner.nextLine();
String author2 = scanner.nextLine();
int year2 = scanner.nextInt();
scanner.nextLine();

String genre2 = scanner.nextLine();
Book book2 = new Book(title2, author2, year2, genre2);

System.out.println("Book 3:");
String title3 = scanner.nextLine();
String author3 = scanner.nextLine();
int year3 = scanner.nextInt();
scanner.nextLine();
String genre3 = scanner.nextLine();
Book book3 = new Book(title3, author3, year3, genre3);

System.out.println("Book Details:");
book1.displayDetails();
book2.displayDetails();
book3.displayDetails();
Book.displayTotalBooks();

scanner.close();
}
}

