package employee.employee;

public class employee {
public String name;
public int id;
public int salary;
public String designation;

public employee() {
this.name = "Unknown";

this.id = 0;
this.salary = 0;
this.designation = "Unknown";
}

public employee(String name, int id) {
this.name = name;
this.id = id;
this.salary = 0;
this.designation = "Unknown";
}
public employee(String name, int age, String gender, String address) {
this.name = name;
this.id = id;
this.salary = salary;
this.designation = designation;
}
public void updateemployee(String name, int id) {
this.name = name;
this.id = id;
}
public void updateemployee(int salary, String designation) {
this.salary = salary;
this.designation = designation;
}
public void displayemployeeInfo() {
System.out.println("Name: " + this.name);

System.out.println("ID: " + this.id);
System.out.println("Salary: " + this.salary);
System.out.println("Designation: " + this.designation);
}
public static void main(String[] args) {
employee employee1 = new employee();
employee1.displayemployeeInfo();

System.out.println();
employee employee2 = new employee("ABIR", 242314);
employee2.displayemployeeInfo();
System.out.println();
employee employee3 = new employee("BORNA",242330,"25000",
"Executive");
employee3.displayemployeeInfo();
System.out.println();
employee2.updateemployee("SEHRISH", 242326);
employee2.displayemployeeInfo();
System.out.println();
employee3.updateemployee(35000, "Marketing head executive");
employee3.displayemployeeInfo();
}
}
