
package employee.employee;

public class Employee {
private String name;
private int id;
private double salary;
private String designation;

public Employee() {
this.name = "Unknown";
this.id = 0;
this.salary = 0.0;
this.designation = "Unknown";
}
public Employee(String name, int id) {
this.name = name;
this.id = id;
this.salary = 0.0;
this.designation = "Unknown";
}

public Employee(String name, int id, double salary, String designation) {
this.name = name;
this.id = id;
this.salary = salary;
this.designation = designation;
}
public String getName() {
return name; }
public void setName(String name) {
this.name = name; }
public int getId() {
return id; }
public void setId(int id) {
this.id = id;}
public double getSalary() {
return salary; }
public void setSalary(double salary) {
this.salary = salary; }
public String getDesignation() {
return designation; }
public void setDesignation(String designation) {
this.designation = designation;}
public void updateEmployee(String name, int id) {
this.name = name;
this.id = id;
}

public void updateEmployee(double salary, String designation) {
this.salary = salary;
this.designation = designation;
}
public void displayEmployeeInfo() {
System.out.println("Name: " + this.name);
System.out.println("ID: " + this.id);
System.out.println("Salary: " + this.salary);
System.out.println("Designation: " + this.designation);
}
public static void main(String[] args) {
Employee emp1 = new Employee();
emp1.displayEmployeeInfo();
System.out.println();
Employee emp2 = new Employee("KASMIR HASAN", 245101);
emp2.displayEmployeeInfo();
System.out.println();
Employee emp3 = new Employee("FABIHA ISLAM", 245102, 75000.0, "Software eng");
emp3.displayEmployeeInfo();
System.out.println();
emp2.updateEmployee("MAHIR RASHID", 245103);
emp2.displayEmployeeInfo();
System.out.println();
emp3.updateEmployee(80000.0, "Senior Software Engineer");
emp3.displayEmployeeInfo();

}
}
