package student.student;

import java.util.Scanner;

class Student {
private final int id;
private final String name;
private final String department;
private final double cgpa;
private static String university;
private static int studentCount = 0;

public Student(int id, String name, String department, double cgpa,
String university) {
this.id = id;
this.name = name;
this.department = department;
this.cgpa = cgpa;
Student.university = university;
studentCount++;
}

public void displayDetails() {
System.out.println("ID: " + id);
System.out.println("Name: " + name);
System.out.println("Department: " + department);
System.out.println("CGPA: " + cgpa);
System.out.println("University: " + university);
System.out.println();
}
public static void displayTotalStudents() {
System.out.println("Total number of students: " + studentCount);
}
public static void main(String[] args) {

Scanner scanner = new Scanner(System.in);
System.out.println("Enter the university name:");
String university = scanner.nextLine();

System.out.println("\nStudent 1: ID,Name,Department,CGPA");
int id1 = scanner.nextInt();
scanner.nextLine();
String name1 = scanner.nextLine();
String department1 = scanner.nextLine();
double cgpa1 = scanner.nextDouble();
scanner.nextLine();
Student student1 = new Student(id1, name1, department1, cgpa1,
university);

System.out.println("Student 2: ID,Name,Department,CGPA ");
int id2 = scanner.nextInt();
scanner.nextLine();
String name2 = scanner.nextLine();
String department2 = scanner.nextLine();
double cgpa2 = scanner.nextDouble();
scanner.nextLine();
Student student2 = new Student(id2, name2, department2, cgpa2,
university);

System.out.println("Student 3: ID,Name,Department,CGPA ");
int id3 = scanner.nextInt();
scanner.nextLine();
String name3 = scanner.nextLine();
String department3 = scanner.nextLine();
double cgpa3 = scanner.nextDouble();
scanner.nextLine();
Student student3 = new Student(id3, name3, department3, cgpa3,
university);

System.out.println("Student Details:");
student1.displayDetails();
student2.displayDetails();
student3.displayDetails();
Student.displayTotalStudents();
scanner.close();
}
}

