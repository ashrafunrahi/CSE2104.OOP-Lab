package java.student;
import java.util.Scanner;
public class Student {
private final int id;
private final String name;
private final String department;
private final double cgpa;
private static String university = "My University";
public Student(int id, String name, String department, double cgpa) {
this.id = id;
this.name = name;
this.department = department;
this.cgpa = cgpa;

}
public void display() {
System.out.println("ID: " + id);
System.out.println("Name: " + name);
System.out.println("Department: " + department);
System.out.println("CGPA: " + cgpa);
System.out.println("University: " + university);
System.out.println();
}
public static void getTotalStudents(Student[] students) {
System.out.println("Total number of students: " + students.length);
}
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
Student[] students = new Student[3];
for (int i = 0; i < 3; i++) {
System.out.println("Enter details for Student " + (i + 1) + ":");
System.out.print("ID: ");
int id = scanner.nextInt();
scanner.nextLine();
System.out.print("Name: ");
String name = scanner.nextLine();

System.out.print("Department: ");
String department = scanner.nextLine();
System.out.print("CGPA: ");
double cgpa = scanner.nextDouble();
scanner.nextLine();
Student student = new Student(id, name, department, cgpa);
students[i] = student;
}
System.out.println("\nAll Students:");
for (Student student : students) {
student.display();
}
Student.getTotalStudents(students);
scanner.close();
}
}

