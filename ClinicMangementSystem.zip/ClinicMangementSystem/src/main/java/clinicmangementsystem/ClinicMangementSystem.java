
package clinicmangementsystem;
import java.io.*;
import java.util.*;

public class ClinicMangementSystem 
{
    private static List<Doctor> doctors = new ArrayList<>();
    private static List<Appointment> appointments = new ArrayList<>();

    public static void main(String[] args) {
       
        doctors.add(new NewPractitioner("Dr. Ashrafun"));
        doctors.add(new Specialist("Dr. Mohammad Ali"));
        doctors.add(new InternDoctor("Dr. Imran"));
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n Clinic Management System :-");
            System.out.println("1. View All Doctors");
            System.out.println("2. Book an Appointment");
            System.out.println("3. View Appointment Schedule");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    viewDoctors();
                    break;
                case 2:
                    bookAppointment(scanner);
                    break;
                case 3:
                    viewAppointments();
                    break;
                case 4:
                    System.out.println("Exiting the system");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void viewDoctors() {
        System.out.println("\n Available Doctors:-");
        for (Doctor doctor : doctors) {
            System.out.print(doctor.getName() + " (" + doctor.getSpecialization() + ") - ");
            doctor.displayAvailability();
        }
    }

    private static void bookAppointment(Scanner scanner) {
        System.out.println("\n Book an Appointment:-");
        System.out.print("Enter name: ");
        String patientName = scanner.nextLine();
        Patient patient = new Patient(patientName);

        System.out.println("Select a doctor:");
        for (int i = 0; i < doctors.size(); i++) {
            System.out.println((i + 1) + ". " + doctors.get(i).getName() + " (" + doctors.get(i).getSpecialization() + ")");
        }
        int doctorChoice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        if (doctorChoice < 1 || doctorChoice > doctors.size()) {
            System.out.println("Invalid choice. Appointment not booked.");
            return;
        }
        Doctor selectedDoctor = doctors.get(doctorChoice - 1);
        System.out.print("Enter appointment time: ");
        String appointmentTime = scanner.nextLine();

        Appointment appointment = new Appointment(selectedDoctor, patient, appointmentTime);
        appointments.add(appointment);

        try {
            appointment.saveToFile();
            System.out.println("Appointment booked successfully and saved to file.");
        } catch (IOException e) {
            System.out.println("Error saving appointment: " + e.getMessage());
        }
    }

    private static void viewAppointments() {
        System.out.println("\n Appointment Schedule:-");
        if (appointments.isEmpty()) {
            System.out.println("No appointments scheduled.");
        } else {
            for (Appointment appointment : appointments) {
                System.out.println(appointment);
            }
        }
    }
}
