
package clinicmangementsystem;

public class Doctor 
{
    private String name;
    private String specialization;

    public Doctor(String name, String specialization) {
        this.name = name;
        this.specialization = specialization;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public void displayAvailability() {
        System.out.println("Availability not set.");
    }
}

class NewPractitioner extends Doctor {
    public NewPractitioner(String name) {
        super(name, "New Practitioner");
    }

    public void displayAvailability() {
        System.out.println("Available for walk-in patient from 10 AM to 6 PM.");
    }
}

class Specialist extends Doctor {
    public Specialist(String name) {
        super(name, "Specialist");
    }

    public void displayAvailability() {
        System.out.println("Available by appointment only.");
    }
}

class InternDoctor extends Doctor {
    public InternDoctor(String name) {
        super(name, "Intern Doctor");
    }

    public void displayAvailability() {
        System.out.println("Available for consultation under supervision from 12 PM to 4 PM.");
    }
}

class Patient {
    private String name;

    public Patient(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

class Appointment {
    private Doctor doctor;
    private Patient patient;
    private String appointmentTime;

    public Appointment(Doctor doctor, Patient patient, String appointmentTime) {
        this.doctor = doctor;
        this.patient = patient;
        this.appointmentTime = appointmentTime;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public String getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public String toString() {
        return "Doctor: " + doctor.getName() + " (" + doctor.getSpecialization() + "), " +
                "Patient: " + patient.getName() + ", Appointment Time: " + appointmentTime;
    }

    public void saveToFile() throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("appointments.txt", true));
        writer.write(toString() + "\n");
        writer.close();
    }
}
